export default {
  _widgetLabel: 'Widget Controller',
  _action_openWidget_label: 'Open widget',
  resizerTooltip: 'Customize the window size by dragging and dropping.'
}
